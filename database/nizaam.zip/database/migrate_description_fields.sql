-- Migrate description fields from TEXT to LONGTEXT to support base64 images
-- Run this migration to fix image storage issues

USE nizaam;

-- Work items descriptions (includes tasks, leaves, expenses, timesheets)
ALTER TABLE work_items MODIFY COLUMN description LONGTEXT NULL;

-- Projects descriptions
ALTER TABLE projects MODIFY COLUMN description LONGTEXT NULL;

-- Comments (can contain rich text with images)
ALTER TABLE comments MODIFY COLUMN comment LONGTEXT NOT NULL;

-- Workflows descriptions
ALTER TABLE workflows MODIFY COLUMN description LONGTEXT NULL;

-- Leave types descriptions
ALTER TABLE leave_types MODIFY COLUMN description LONGTEXT NULL;

-- Work item history comments
ALTER TABLE work_item_history MODIFY COLUMN comment LONGTEXT NULL;
